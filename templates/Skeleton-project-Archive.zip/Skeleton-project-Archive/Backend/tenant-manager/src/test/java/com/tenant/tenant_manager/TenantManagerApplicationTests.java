package com.tenant.tenant_manager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TenantManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
