package com.tenant.controller;

import org.quartz.SchedulerException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author Muhil
 */
@RestController
public class TenantController {
	
	@Value("${encryption.jwt.secret}")
	private String val;

	
	@GetMapping("/ping")
	public String pingTenant() throws SchedulerException {
		return val;
	}

}
