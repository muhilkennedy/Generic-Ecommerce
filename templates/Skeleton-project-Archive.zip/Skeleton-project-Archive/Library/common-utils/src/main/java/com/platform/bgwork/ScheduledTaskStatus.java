package com.platform.bgwork;

/**
 * @author muhil
 *
 */
public enum ScheduledTaskStatus {
	
	CREATED, FAILED, SUCCESS, INPROGRESS,

}