package com.platform.antivirus;

/**
 * @author Muhil
 */
public enum VirusScanStatus {

	PASSED, FAILED, ERROR, CONNECTION_FAILED;

}
