package com.platform.exceptions;

/**
 * @author Muhil
 */
public class EncryptionException extends Exception {

	private static final long serialVersionUID = 168608124581689672L;

}
