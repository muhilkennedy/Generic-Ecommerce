import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { environment } from '../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class TenantinitalizerService {

  constructor(
    private http: HttpClient,
    private router: Router
  ) {}

  initializeApp(): Promise<any> {
    console.log('Initializing app...');
    return new Promise((resolve, reject) => {
      this.http.get(`${environment.apiUrl}/tm/ping`)
        .subscribe({
          next: (resp: any) => {
            console.log('Tenant details loaded:', resp);
            resolve(true);
          },
          error: (error) => {
            console.error('Error loading tenant details:', error);
            resolve(false);
            this.router.navigate(['/auth/error']);
          },
          complete: () => console.log('App initialization complete.')
        });
    });
  }
}

