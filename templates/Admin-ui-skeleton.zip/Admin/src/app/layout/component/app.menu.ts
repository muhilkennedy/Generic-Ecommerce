import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { MenuItem } from 'primeng/api';
import { AppMenuitem } from './app.menuitem';

@Component({
    selector: 'app-menu',
    standalone: true,
    imports: [CommonModule, AppMenuitem, RouterModule],
    template: `<ul class="layout-menu">
        <ng-container *ngFor="let item of model; let i = index">
            <li app-menuitem *ngIf="!item.separator" [item]="item" [index]="i" [root]="true"></li>
            <li *ngIf="item.separator" class="menu-separator"></li>
        </ng-container>
    </ul> `
})
export class AppMenu {
    model: MenuItem[] = [];

    ngOnInit() {
        this.model = [
            {
                label: 'Home',
                items: [{ label: 'Dashboard', icon: 'pi pi-fw pi-home', routerLink: ['/'] }]
            },
            {
                label: 'Tenant Manager',
                items: [
                    { label: 'View Tenant', icon: 'pi pi-fw pi-list', routerLink: ['/uikit/formlayout'] },
                    { label: 'Onboard Tenant', icon: 'pi pi-fw pi-plus', routerLink: ['/uikit/formlayout'] },
                    { label: 'Edit Tenant', icon: 'pi pi-fw pi-pencil', routerLink: ['/uikit/formlayout'] }
                ]
            },
            {
                label: 'User Manager',
                icon: 'pi pi-fw pi-briefcase',
                routerLink: ['/pages'],
                items: [
                    {
                        label: 'Employee',
                        icon: 'pi pi-fw pi-users',
                        items: [
                            {
                                label: 'View',
                                icon: 'pi pi-fw pi-list',
                                routerLink: ['/auth/access']
                            },
                            {
                                label: 'Onboard',
                                icon: 'pi pi-fw pi-user-plus',
                                routerLink: ['/auth/login']
                            },
                            {
                                label: 'Edit',
                                icon: 'pi pi-fw pi-user-edit',
                                routerLink: ['/auth/error']
                            },
                            {
                                label: 'Permissions',
                                icon: 'pi pi-fw pi-key',
                                items: [
                                    {
                                        label: 'View',
                                        icon: 'pi pi-fw pi-list-check',
                                        routerLink: ['/auth/login']
                                    },
                                    {
                                        label: 'Edit',
                                        icon: 'pi pi-fw pi-pencil',
                                        routerLink: ['/auth/error']
                                    }
                                ]
                            }
                        ]
                    },
                    {
                        label: 'Customer',
                        icon: 'pi pi-fw pi-users',
                        items: [
                            {
                                label: 'View',
                                icon: 'pi pi-fw pi-list',
                                routerLink: ['/auth/access']
                            },
                            {
                                label: 'Edit',
                                icon: 'pi pi-fw pi-user-edit',
                                routerLink: ['/auth/error']
                            }
                        ]
                    },
                ]
            },
            {
                label: 'Inventory Manager',
                routerLink: ['/pages'],
                items: [
                    {
                        label: 'Supplier Manager',
                        icon: 'pi pi-fw pi-warehouse',
                        items: [
                            { label: 'View Suppliers', icon: 'pi pi-fw pi-list', routerLink: ['/uikit/formlayout'] },
                            { label: 'Add Supplier', icon: 'pi pi-fw pi-plus', routerLink: ['/uikit/formlayout'] },
                            { label: 'Edit Supplier', icon: 'pi pi-fw pi-pencil', routerLink: ['/uikit/formlayout'] }
                        ]
                    },
                    {
                        label: 'Product Manager',
                        icon: 'pi pi-fw pi-shopping-bag',
                        items: [
                            { label: 'View Products', icon: 'pi pi-fw pi-list-check', routerLink: ['/uikit/formlayout'] },
                            { label: 'Add Product', icon: 'pi pi-fw pi-plus', routerLink: ['/uikit/formlayout'] },
                            { label: 'Edit Product', icon: 'pi pi-fw pi-pencil', routerLink: ['/uikit/formlayout'] }
                        ]
                    },
                    { label: 'Servicable Pincodes', icon: 'pi pi-fw pi-truck', routerLink: ['/uikit/formlayout'] }
                ]
            },
            {
                label: 'Sales Manager',
                routerLink: ['/pages'],
                items: [
                    { label: 'POS', icon: 'pi pi-fw pi-shop', routerLink: ['/uikit/formlayout'] },
                    {
                        label: 'Order Management',
                        icon: 'pi pi-fw pi-shopping-cart',
                        items: [
                            { label: 'View Orders', icon: 'pi pi-fw pi-list', routerLink: ['/uikit/formlayout'] },
                            { label: 'Edit Order', icon: 'pi pi-fw pi-cart-plus', routerLink: ['/uikit/formlayout'] }
                        ]
                    },
                    {
                        label: 'Shipping Manager',
                        icon: 'pi pi-fw pi-truck',
                        items: [
                            { label: 'Shipped Products', icon: 'pi pi-fw pi-list', routerLink: ['/uikit/formlayout'] },
                            { label: 'Create Shipment', icon: 'pi pi-fw pi-plus-circle', routerLink: ['/uikit/formlayout'] },
                            { label: 'Update Status', icon: 'pi pi-fw pi-pencil', routerLink: ['/uikit/formlayout'] }
                        ]
                    }
                ]
            },
            {
                label: 'Reporting Manager',
                items: [
                    {
                        label: 'Analytics',
                        icon: 'pi pi-fw pi-chart-line',
                        routerLink: ['/documentation']
                    }
                ]
            },
            {
                label: 'Promotional Manager',
                items: [
                    {
                        label: 'Coupon Management', 
                        icon: 'pi pi-fw pi-gift',
                        items: [
                            { label: 'View Coupons', icon: 'pi pi-fw pi-list-check', routerLink: ['/uikit/formlayout'] },
                            { label: 'Add Coupons', icon: 'pi pi-fw pi-plus-circle', routerLink: ['/uikit/formlayout'] }
                        ]
                    },
                    {
                        label: 'File Storage',
                        icon: 'pi pi-fw pi-file',
                        routerLink: ['/documentation']
                    },
                    {
                        label: 'Home Page Banners',
                        icon: 'pi pi-fw pi-images',
                        routerLink: ['/documentation']
                    }
                ]
            },
            {
                label: 'Configuration Manager',
                items: [
                    {
                        label: 'Email Configuration',
                        icon: 'pi pi-fw pi-envelope',
                        routerLink: ['/documentation']
                    },
                    {
                        label: 'Storage Configuration',
                        icon: 'pi pi-fw pi-cloud',
                        routerLink: ['/documentation']
                    }
                ]
            },
            {
                label: 'Service Manager',
                items: [
                    {
                        label: 'Audit Logs',
                        icon: 'pi pi-fw pi-book',
                        routerLink: ['/documentation']
                    },
                    {
                        label: 'Scheduled Tasks',
                        icon: 'pi pi-fw pi-hourglass',
                        url: 'https://github.com/primefaces/sakai-ng',
                        target: '_blank'
                    }
                ]
            }
        ];
    }
}
