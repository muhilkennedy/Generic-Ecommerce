export const environment = {
    production: false,
    tenantId: 'devTenant',
    apiUrl: 'http://localhost:8081'
};