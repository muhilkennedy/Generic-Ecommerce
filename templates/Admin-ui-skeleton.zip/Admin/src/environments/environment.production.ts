export const environment = {
    production: true,
    tenantId: 'devTenant',
    apiUrl: 'http://localhost:8081'
};