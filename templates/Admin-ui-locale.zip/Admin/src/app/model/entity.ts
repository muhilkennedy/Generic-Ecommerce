export class Entity {
    rootid!: number;
    timecreated!: number;
    timeupdated!: number;
    uniquename!: string;
    version!: number;
    active!: boolean;
    createdby!: number;
    modifiedby!: number;
}